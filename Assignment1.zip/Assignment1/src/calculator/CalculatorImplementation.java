package calculator;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Stack;

public class CalculatorImplementation extends UnicastRemoteObject implements Calculator {
    private Stack<Integer> stack;

    // Constructor initializes the stack and handles RemoteException
    public CalculatorImplementation() throws RemoteException {
        stack = new Stack<>();
    }

    /**
     * Pushes a value onto the stack.
     * @param val the integer value to be pushed onto the stack.
     * @throws RemoteException if a remote communication error occurs.
     */
    @Override
    public synchronized void pushValue(int val) throws RemoteException {
        stack.push(val);
    }

    /**
     * Pushes an operator onto the stack, computes the result based on the operator, 
     * and pushes the result back onto the stack.
     * 
     * @param operator the operator to be pushed ("min", "max", "lcm", "gcd").
     * @throws RemoteException if a remote communication error occurs.
     * @throws IllegalArgumentException if the operator is invalid.
     */
    @Override
    public synchronized void pushOperation(String operator) throws RemoteException {
        int result;
        switch (operator) {
            case "min":
                result = findMin();
                break;
            case "max":
                result = findMax();
                break;
            case "lcm":
                result = findLcm();
                break;
            case "gcd":
                result = findGcd();
                break;
            default:
                throw new IllegalArgumentException("Invalid operator: " + operator);
        }
        stack.clear();
        stack.push(result);
    }

    /**
     * Pops the top value off the stack.
     * 
     * @return the integer value that was on top of the stack.
     * @throws RemoteException if a remote communication error occurs or if the stack is empty.
     */
    @Override
    public synchronized int pop() throws RemoteException {
        if (stack.isEmpty()) {
            throw new RemoteException("Stack is empty");
        }
        return stack.pop();
    }

    /**
     * Checks if the stack is empty.
     * 
     * @return true if the stack is empty, false otherwise.
     * @throws RemoteException if a remote communication error occurs.
     */
    @Override
    public synchronized boolean isEmpty() throws RemoteException {
        return stack.isEmpty();
    }

    /**
     * Delays for a specified amount of time before popping the top value off the stack.
     * 
     * @param millis the number of milliseconds to delay.
     * @return the integer value that was on top of the stack after the delay.
     * @throws RemoteException if a remote communication error occurs or if the stack is empty.
     */
    @Override
    public synchronized int delayPop(int millis) throws RemoteException {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            throw new RemoteException("Interrupted", e);
        }
        return pop();
    }

    /**
     * Helper method to find the minimum value in the stack.
     * 
     * @return the minimum value in the stack.
     * @throws RemoteException if the stack is empty.
     */
    private int findMin() throws RemoteException {
        if (stack.isEmpty()) {
            throw new RemoteException("Stack is empty");
        }
        int min = Integer.MAX_VALUE;
        for (int val : stack) {
            if (val < min) {
                min = val;
            }
        }
        return min;
    }

    /**
     * Helper method to find the maximum value in the stack.
     * 
     * @return the maximum value in the stack.
     * @throws RemoteException if the stack is empty.
     */
    private int findMax() throws RemoteException {
        if (stack.isEmpty()) {
            throw new RemoteException("Stack is empty");
        }
        int max = Integer.MIN_VALUE;
        for (int val : stack) {
            if (val > max) {
                max = val;
            }
        }
        return max;
    }

    /**
     * Helper method to calculate the LCM of values in the stack.
     * 
     * @return the LCM of values in the stack.
     * @throws RemoteException if the stack is empty.
     */
    private int findLcm() throws RemoteException {
        if (stack.isEmpty()) {
            throw new RemoteException("Stack is empty");
        }
        int lcm = 1;
        for (int val : stack) {
            lcm = lcm(lcm, val);
        }
        return lcm;
    }

    /**
     * Helper method to calculate the GCD of values in the stack.
     * 
     * @return the GCD of values in the stack.
     * @throws RemoteException if the stack is empty.
     */
    private int findGcd() throws RemoteException {
        if (stack.isEmpty()) {
            throw new RemoteException("Stack is empty");
        }
        int gcd = 0;
        for (int val : stack) {
            gcd = gcd(gcd, val);
        }
        return gcd;
    }

    /**
     * Computes the greatest common divisor (GCD) of two integers.
     * 
     * @param a the first integer.
     * @param b the second integer.
     * @return the GCD of the two integers.
     */
    private int gcd(int a, int b) {
        while (b != 0) {
            int t = b;
            b = a % b;
            a = t;
        }
        return a;
    }

    /**
     * Computes the least common multiple (LCM) of two integers.
     * 
     * @param a the first integer.
     * @param b the second integer.
     * @return the LCM of the two integers.
     */
    private int lcm(int a, int b) {
        return a * (b / gcd(a, b));
    }
}
