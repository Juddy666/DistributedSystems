package calculator;

import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class CalculatorServer {
    public static void main(String[] args) {
        try {
            CalculatorImplementation calc = new CalculatorImplementation();
            Registry registry = LocateRegistry.getRegistry(2002); // Get the existing registry on port 2002
            registry.rebind("Calculator", calc);
            System.out.println("Calculator Server ready");
        } catch (Exception e) {
            System.err.println("Calculator Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
