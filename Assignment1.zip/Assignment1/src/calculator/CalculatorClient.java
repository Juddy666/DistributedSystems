package calculator;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CalculatorClient {
    private CalculatorClient() {}

    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry(null, 2002);
            Calculator stub = (Calculator) registry.lookup("Calculator");

            stub.pushValue(10);
            stub.pushValue(20);
            stub.pushOperation("gcd");
            int result = stub.pop();
            System.out.println("GCD: " + result);

            stub.pushValue(10);
            stub.pushValue(20);
            stub.pushOperation("lcm");
            result = stub.pop();
            System.out.println("LCM: " + result);

            // operations
            stub.pushValue(30);
            stub.pushValue(40);
            stub.pushOperation("min");
            result = stub.pop();
            System.out.println("Min: " + result);

            stub.pushValue(50);
            stub.pushValue(60);
            stub.pushOperation("max");
            result = stub.pop();
            System.out.println("Max: " + result);

            System.out.println("Is stack empty? " + stub.isEmpty());
        } catch (Exception e) {
            System.err.println("CalculatorClient exception: " + e.toString());
            e.printStackTrace();
        }
    }
}


